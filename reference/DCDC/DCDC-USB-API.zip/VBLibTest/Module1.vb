Imports System.Runtime.InteropServices
Imports System.Text

Module Module1

    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcOpenDevice(ByVal timer As Integer) As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Sub dcdcCloseDevice()
    End Sub
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetConnected() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetTimeCfg() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetVoltageCfg() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetMode() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetState() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetVin() As Single
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetVIgn() As Single
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetVOut() As Single
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetEnabledPowerSwitch() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetEnabledOutput() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetEnabledAuxVOut() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetFlagsStatus1() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetFlagsStatus2() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetFlagsVoltage() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetFlagsTimer() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetFlashPointer() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetTimerWait() As UInt32
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetTimerVout() As UInt32
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetTimerVAux() As UInt32
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetTimerPwSwitch() As UInt32
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetTimerOffDelay() As UInt32
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetTimerHardOff() As UInt32
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetVersionMajor() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetVersionMinor() As Byte
    End Function

    'Set stuff
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Sub dcdcSetEnabledAuxVOut(ByVal set_on As Byte)
    End Sub
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Sub dcdcSetEnabledPowerSwitch(ByVal set_on As Byte)
    End Sub
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Sub dcdcSetEnabledOutput(ByVal set_on As Byte)
    End Sub
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Sub dcdcIncDecVOutVolatile(ByVal set_inc As Byte)
    End Sub
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Sub dcdcSetVOutVolatile(ByVal vout As Single)
    End Sub

    'Flash stuff
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Sub dcdcLoadFlashValues()
    End Sub
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetLoadState() As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Function dcdcGetMaxVariableCnt() As UInt32
    End Function
    <DllImport("DCDCUsbLib.dll", CharSet:=CharSet.Ansi, CallingConvention:=CallingConvention.Cdecl)> _
    Function dcdcGetVariableData(ByVal cnt As UInt32, ByVal name As StringBuilder, ByVal value As StringBuilder, ByVal unit As StringBuilder, ByVal comment As StringBuilder) As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CharSet:=CharSet.Ansi, CallingConvention:=CallingConvention.Cdecl)> _
    Function dcdcSetVariableData(ByVal cnt As UInt32, ByVal value As String) As Byte
    End Function
    <DllImport("DCDCUsbLib.dll", CallingConvention:=CallingConvention.Cdecl)> Sub dcdcSaveFlashValues()
    End Sub

    Sub Main()
        Dim sCurPath
        sCurPath = CreateObject("Scripting.FileSystemObject").GetAbsolutePathName(".")
        Console.WriteLine(sCurPath)

        Dim bRes As Byte
        bRes = dcdcOpenDevice(1000)

        If (bRes) Then
            Console.WriteLine("DCDC Found!")
            System.Threading.Thread.CurrentThread.Sleep(1000)
            Console.Write("V")
            Console.Write(dcdcGetVersionMajor())
            Console.Write(".")
            Console.Write(dcdcGetVersionMinor())
            Console.WriteLine()
        Else
            Console.WriteLine("DCDC Not found!")
        End If

        Console.WriteLine("Press Esc to exit")

        Dim cki As ConsoleKeyInfo

        Do
            If (Console.KeyAvailable) Then
                cki = Console.ReadKey()
                Select Case cki.Key
                    Case ConsoleKey.D1
                        Console.Write("===> AUX ON")
                        dcdcSetEnabledAuxVOut(1)
                    Case ConsoleKey.D2
                        Console.Write("===> AUX OFF")
                        dcdcSetEnabledAuxVOut(0)
                    Case ConsoleKey.D3
                        Console.Write("===> Power ON")
                        dcdcSetEnabledPowerSwitch(1)
                    Case ConsoleKey.D4
                        Console.Write("===> Power OFF")
                        dcdcSetEnabledPowerSwitch(0)
                    Case ConsoleKey.D5
                        Console.Write("===> VOut ON")
                        dcdcSetEnabledOutput(1)
                    Case ConsoleKey.D6
                        Console.Write("===> VOut OFF")
                        dcdcSetEnabledOutput(0)
                    Case ConsoleKey.D7
                        Console.Write("===> VOut INC")
                        dcdcIncDecVOutVolatile(1)
                    Case ConsoleKey.D8
                        Console.Write("===> VOut DEC")
                        dcdcIncDecVOutVolatile(0)
                    Case ConsoleKey.D9
                        Console.Write("===> VOut Direct 12V")
                        dcdcSetVOutVolatile(12.0)
                    Case ConsoleKey.L
                        Console.Write("===> Loading flash")
                        dcdcLoadFlashValues()

                        Dim timeout As Integer
                        timeout = 0

                        Do
                            timeout = timeout + 1
                            System.Threading.Thread.CurrentThread.Sleep(1000)
                        Loop While timeout < 10 And dcdcGetLoadState() < 100
                        Console.Write("Loading flash =")
                        Console.Write(dcdcGetLoadState())
                        Console.WriteLine()

                        If (dcdcGetLoadState() = 100) Then
                            Dim max As UInt32 = dcdcGetMaxVariableCnt() - 1
                            Console.Write("Variables=")
                            Console.Write(max)
                            Console.WriteLine()
                            For index As UInt32 = 0 To max
                                Dim value As StringBuilder = New StringBuilder(256)
                                Dim unit As StringBuilder = New StringBuilder(256)
                                Dim name As StringBuilder = New StringBuilder(256)
                                Dim comment As StringBuilder = New StringBuilder(1024)
                                If (dcdcGetVariableData(index, name, value, unit, comment)) Then
                                    Console.Write("[")
                                    Console.Write(index)
                                    Console.Write("] ")
                                    Console.Write(name.ToString())
                                    Console.Write("=")
                                    Console.Write(value.ToString())
                                    Console.Write(" ")
                                    Console.Write(unit.ToString())
                                    Console.WriteLine()
                                    'Else
                                    'Console.Write("[")
                                    'Console.Write(index)
                                    'Console.Write("] not used")
                                    'Console.WriteLine()
                                End If
                            Next
                        End If
                    Case ConsoleKey.Q
                        Console.Write("===> Saving flash 1")
                        'see complete list with ConsoleKey.L (format is displayed too)
                        dcdcSetVariableData(0, "20.11") 'Voltage 0 (VOut at startup)
                        dcdcSetVariableData(10, "511") 'Ignition debounce
                        dcdcSetVariableData(20, "10001101") 'config flags
                        dcdcSetVariableData(24, "Never") 'Off-delay TIME 1
                        dcdcSaveFlashValues()
                    Case ConsoleKey.W
                        Console.Write("===> Saving flash 2")
                        dcdcSetVariableData(0, "23.35") 'Voltage 0 (VOut at startup)
                        dcdcSetVariableData(10, "500") 'Ignition debounce
                        dcdcSetVariableData(20, "00001101") 'config flags
                        dcdcSetVariableData(24, "00:00:05") 'Off-delay TIME 1
                        dcdcSaveFlashValues()
                End Select
                Console.WriteLine()
            End If

            If dcdcGetConnected() = 0 Then
                dcdcCloseDevice()
                Console.Write("No device")
                Console.WriteLine()
            Else
                Select Case dcdcGetMode()
                    Case 0 : Console.Write("[Dumb]")
                    Case 1 : Console.Write("[Automotive]")
                    Case 2 : Console.Write("[Script]")
                    Case 3 : Console.Write("[UPS]")
                    Case Else : Console.Write("[Error]")
                End Select

                Console.Write(" State:")
                Console.Write(dcdcGetState())
                Console.Write(" VIn:")
                Console.Write(dcdcGetVin())
                Console.Write(" VIgn:")
                Console.Write(dcdcGetVIgn())
                Console.Write(" VOut:")
                Console.Write(dcdcGetVOut())
                Console.Write(" Switches[PW:")
                Console.Write(dcdcGetEnabledPowerSwitch())
                Console.Write(" VOut:")
                Console.Write(dcdcGetEnabledOutput())
                Console.Write(" Aux:")
                Console.Write(dcdcGetEnabledAuxVOut())
                Console.Write("]")
                Console.WriteLine()

                Console.Write("   CfgT:")
                Console.Write(dcdcGetTimeCfg())
                Console.Write(" CfgV:")
                Console.Write(dcdcGetVoltageCfg())
                Console.Write(" Flags[")
                Console.Write(dcdcGetFlagsStatus1())
                Console.Write(" ")
                Console.Write(dcdcGetFlagsStatus2())
                Console.Write(" ")
                Console.Write(dcdcGetFlagsVoltage())
                Console.Write(" ")
                Console.Write(dcdcGetFlagsTimer())
                Console.Write(" ")
                Console.Write(dcdcGetFlashPointer())
                Console.Write("] Timers[")
                Console.Write(dcdcGetTimerWait())
                Console.Write(" ")
                Console.Write(dcdcGetTimerVout())
                Console.Write(" ")
                Console.Write(dcdcGetTimerVAux())
                Console.Write(" ")
                Console.Write(dcdcGetTimerPwSwitch())
                Console.Write(" ")
                Console.Write(dcdcGetTimerOffDelay())
                Console.Write(" ")
                Console.Write(dcdcGetTimerHardOff())
                Console.Write("]")
                Console.WriteLine()
            End If

            System.Threading.Thread.CurrentThread.Sleep(1000)
        Loop While cki.Key <> ConsoleKey.Escape

        dcdcCloseDevice()
    End Sub

End Module
