// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the DCDCUSBLIB_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// DCDCUSBLIB_API functions as being imported from a DLL, whereas this DLL sees symbols
// defined with this macro as being exported.
#ifdef DCDCUSBLIB_EXPORTS
#define DCDCUSBLIB_API __declspec(dllexport)
#else
#define DCDCUSBLIB_API __declspec(dllimport)
#endif

/** Opens first DCDCUsb found on USB
@param timer - milisecond period for data refresh rate. Smaller values 
are forcing the API to refresh the data requested with the rest of the functions 
faster but also will cause data congestion. Recommended values are between 1000-10000
to have a 1-10 second refresh rate
IMPORTANT: after unsuccesfull dcdcOpenDevice call if there is no dcdcCloseDevice call
the API will wait to the first DCDCUsb plugged in and will connect automatically to it! 
@return 1 on success, 0 on fail*/
extern "C" DCDCUSBLIB_API unsigned char dcdcOpenDevice(unsigned int timer);
/** Opens devcount device (1-first device, 2-second ... etc.) 
@param timer - same as dcdcOpenDevice(unsigned int timer);
@return 1 on success, 0 on fail*/
extern "C" DCDCUSBLIB_API unsigned char dcdcOpenDeviceByCnt(unsigned int devcount, unsigned int timer);
/** Get opened device path
@param path - recommended length 1024, will return empty string if no device opened*/
extern "C" DCDCUSBLIB_API void dcdcGetDevicePath(char* path);
/**Close the opened DCDCUsb value*/
extern "C" DCDCUSBLIB_API void dcdcCloseDevice();
/**Get connection state of the DCDCUsb 
@return 1 on connected state, 0 on not connected*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetConnected();

/**@return State variable: Timer config*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetTimeCfg();
/**@return State variable: Voltage config*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetVoltageCfg();
/**@return State variable: Mode (0=Dumb, 1=Automotive, 2=Script, 3=UPS, Other values=ERROR*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetMode();
/**@return State variable: DCDC State*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetState();
/**@return State variable: Voltage In*/
extern "C" DCDCUSBLIB_API float dcdcGetVin();
/**@return State variable: Voltage Ignition*/
extern "C" DCDCUSBLIB_API float dcdcGetVIgn();
/**@return State variable: Voltage Out*/
extern "C" DCDCUSBLIB_API float dcdcGetVOut();
/**@return State variable: Power Switch Enabled*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetEnabledPowerSwitch();
/**@return State variable: Output Enabled*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetEnabledOutput();
/**@return State variable: Auxiliary Output Enabled*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetEnabledAuxVOut();
/**@return State variable: Status flags*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetFlagsStatus1();
/**@return State variable: Status flags*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetFlagsStatus2();
/**@return State variable: Voltage flags*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetFlagsVoltage();
/**@return State variable: Timer flags*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetFlagsTimer();
/**@return State variable: Flash pointer*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetFlashPointer();
/**@return State variable: Wait timer*/
extern "C" DCDCUSBLIB_API unsigned int dcdcGetTimerWait();
/**@return State variable: Voltage Out Timer*/
extern "C" DCDCUSBLIB_API unsigned int dcdcGetTimerVout();
/**@return State variable: Voltage Auxiliary Timer*/
extern "C" DCDCUSBLIB_API unsigned int dcdcGetTimerVAux();
/**@return State variable: Power Switch Timer*/
extern "C" DCDCUSBLIB_API unsigned int dcdcGetTimerPwSwitch();
/**@return State variable: Off Delay Timer*/
extern "C" DCDCUSBLIB_API unsigned int dcdcGetTimerOffDelay();
/**@return State variable: Hard Off Timer*/
extern "C" DCDCUSBLIB_API unsigned int dcdcGetTimerHardOff();
/**@return Firmware version major number */
extern "C" DCDCUSBLIB_API unsigned char dcdcGetVersionMajor();
/**@return Firmware version minor number */
extern "C" DCDCUSBLIB_API unsigned char dcdcGetVersionMinor();

/**Set Auxiliary Output Enable @param on/off*/
extern "C" DCDCUSBLIB_API void dcdcSetEnabledAuxVOut(unsigned char on);
/**Set Power Switch Enable @param on/off*/
extern "C" DCDCUSBLIB_API void dcdcSetEnabledPowerSwitch(unsigned char on);
/**Set Output Enable @param on/off*/
extern "C" DCDCUSBLIB_API void dcdcSetEnabledOutput(unsigned char on);
/**Increase or decrease VOut 
IMPORTANT:this value will be reset together with DCDCUsb Reset.
For permanent values set the flash value and restart the unit
@param inc/dec*/
extern "C" DCDCUSBLIB_API void dcdcIncDecVOutVolatile(unsigned char inc);
/**Set VOut 
IMPORTANT:this value will be reset together with DCDCUsb Reset.
For permanent values set the flash value and restart the unit
@param voltage*/
extern "C" DCDCUSBLIB_API void dcdcSetVOutVolatile(float vout);

/** Start loading flash values. Load state is indicated by dcdcGetLoadState function*/
extern "C" DCDCUSBLIB_API void dcdcLoadFlashValues();
/** Loading state. 100 (%) on success*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetLoadState();
/** Get maximum count of variables in DCDCUsb */
extern "C" DCDCUSBLIB_API unsigned int dcdcGetMaxVariableCnt();
/** Get the data related to a variable. The values will be written in name, value, unit and comment pointers 
so ensure they have enough bytes allocated. Recommended length of buffers are 256 for name, value, unit and 1024 for comment.
IMPORTANT: will return valid data in value only after first succesfull dcdcLoadFlashValues (100%)
@param cnt - variable id, name - variable short name, value - variable value, unit - measuring unit, comment - long comment
@return 1 if the variable does exists*/
extern "C" DCDCUSBLIB_API unsigned char dcdcGetVariableData(unsigned int cnt, char* name, char* value, char* unit, char* comment);
/** Set one data value in PC copy of DCDCUsb Variables. The format for the variables can be different - for list of formats see
either a complete listing of values using dcdcGetVariableData or the DCDCUsb Windows software/Settings tab.
IMPORTANT: this function should be called only after first succesfull dcdcLoadFlashValues otherwise nothing will be saved*/
extern "C" DCDCUSBLIB_API unsigned char dcdcSetVariableData(unsigned int cnt, char* value);
/** Saving the full flash to DCDCUsb (can be more calls of dcdcSetVariableData before one dcdcSaveFlashValues).
Since the flash in the DCDCUsb has a limit of 10k writes we do not recommend functionality which writes the flash
many times.
IMPORTANT: this function should be called only after first succesfull dcdcLoadFlashValues otherwise nothing will be saved*/
extern "C" DCDCUSBLIB_API void dcdcSaveFlashValues();





