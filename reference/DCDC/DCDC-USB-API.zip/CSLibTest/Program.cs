using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace CSLibTest
{
    class Program
    {
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcOpenDevice(int timer);
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern void dcdcCloseDevice();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetConnected();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetTimeCfg();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetVoltageCfg();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetMode();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetState();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern float dcdcGetVin();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern float dcdcGetVIgn();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern float dcdcGetVOut();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetEnabledPowerSwitch();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetEnabledOutput();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetEnabledAuxVOut();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetFlagsStatus1();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetFlagsStatus2();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetFlagsVoltage();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetFlagsTimer();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetFlashPointer();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern int dcdcGetTimerWait();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern int dcdcGetTimerVout();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern int dcdcGetTimerVAux();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern int dcdcGetTimerPwSwitch();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern int dcdcGetTimerOffDelay();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern int dcdcGetTimerHardOff();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetVersionMajor();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetVersionMinor();

        //Set stuff
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern void dcdcSetEnabledAuxVOut(Byte set_on);
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern void dcdcSetEnabledPowerSwitch(Byte set_on);
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern void dcdcSetEnabledOutput(Byte set_on);    
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern void dcdcIncDecVOutVolatile(Byte set_inc);
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern void dcdcSetVOutVolatile(float vout);
        

        //Flash stuff
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern void dcdcLoadFlashValues();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetLoadState();
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern int dcdcGetMaxVariableCnt();
        [DllImport("DCDCUsbLib.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcGetVariableData(int cnt, StringBuilder name, StringBuilder value, StringBuilder unit, StringBuilder comment);    
        [DllImport("DCDCUsbLib.dll", CharSet = CharSet.Ansi, CallingConvention = CallingConvention.Cdecl)] public static extern Byte dcdcSetVariableData(int cnt, String value);
        [DllImport("DCDCUsbLib.dll", CallingConvention = CallingConvention.Cdecl)] public static extern void dcdcSaveFlashValues();
    

        static void Main(string[] args)
        {
            Console.WriteLine(Directory.GetCurrentDirectory());

            Byte bRes = dcdcOpenDevice(1000);
            if (bRes == 1)
                Console.WriteLine("DCDC Found!");
            else
                Console.WriteLine("DCDC Not found!");

            dcdcLoadFlashValues();

            int timeout = 0;
            while ((timeout < 10) && (dcdcGetLoadState() < 100))
            {
                timeout = timeout + 1;
                System.Threading.Thread.Sleep(1000);
            }
            Console.Write("Loading flash =");
            Console.Write(dcdcGetLoadState());
            Console.WriteLine();

            if (dcdcGetLoadState() == 100)
            {
                int max = dcdcGetMaxVariableCnt() - 1;
                Console.Write("Variables=");
                Console.Write(max);
                Console.WriteLine();
                for (int index = 0; index <= max; index++)
                {
                    StringBuilder value = new StringBuilder(256);
                    StringBuilder unit  = new StringBuilder(256);
                    StringBuilder name  = new StringBuilder(256);
                    StringBuilder comment = new StringBuilder(1024);
                    if (dcdcGetVariableData(index, name, value, unit, comment) == 1)
                    {
                        Console.Write("[");
                        Console.Write(index);
                        Console.Write("] ");
                        Console.Write(name.ToString());
                        Console.Write("=");
                        Console.Write(value.ToString());
                        Console.Write(" ");
                        Console.Write(unit.ToString());
                        Console.WriteLine();
                    } 
                    else
                    {
                        //Console.Write("[")
                        //Console.Write(index)
                        //Console.Write("] not used")
                        //Console.WriteLine()
                    }
                }
            }

            dcdcSetVariableData(0, "23.35");//Voltage 0 (VOut at startup)
            dcdcSetVariableData(10, "500");//Ignition debounce
            dcdcSetVariableData(20, "00001101");//config flags
            dcdcSetVariableData(24, "00:00:05");//Off-delay TIME 1

            dcdcSaveFlashValues();

            Console.WriteLine("Press any key to exit!");
            while (!Console.KeyAvailable) ;
        }
    }
}
