// DCDCUsbLibTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <windows.h>
#include <conio.h>
#include "..\DCDCUsbLib\DCDCUsbLib.h"

int _tmain(int argc, _TCHAR* argv[])
{
	printf("HIT <Esc> TO EXIT!\n");
	dcdcOpenDevice(1000);
	//if (dcdcOpenDeviceByCnt(2, 1000))
	if (dcdcGetConnected())
	{
		printf("DCDC opened!\n");
		Sleep(500);	//it's recommended to give a few miliseconds before the first read otherwise the first read might be 0 

		//the library reads the UPS values in every 1000 msec (once per second)
		//therefore is useless to read them faster from here

		char path[1024];
		dcdcGetDevicePath(path);
		
		printf(" firmware: %02d.%02d \n",dcdcGetVersionMajor(),dcdcGetVersionMinor());
		printf(" mode: %d\n",dcdcGetMode());
		printf(" path: %s\n",path);
		printf("------------------------------\n");
	}
	else printf("DCDC not found!\n");

	char ch = 0;

	while (ch != 27)
	{
		if (_kbhit())
		{
			ch = _getch();
			if (ch != 27)
			{
				printf("Press again:\n1.Switch aux ON\n2.switch aux OFF\n3.Switch power ON\n4.Switch power OFF\n5.Switch VOut ON\n6.Switch VOut OFF\n");
				printf("7.Increase VOut\n8.Decrease VOut\n9.Set VOut\nL.Load flash");
				ch = _getch();
				switch (ch)
				{
				case '1': printf("AUX ON\n");dcdcSetEnabledAuxVOut(true); break;
				case '2': printf("AUX OFF\n");dcdcSetEnabledAuxVOut(false); break;
				case '3': printf("Power ON\n");dcdcSetEnabledPowerSwitch(true); break;
				case '4': printf("Power OFF\n");dcdcSetEnabledPowerSwitch(false); break;
				case '5': printf("VOut ON\n");dcdcSetEnabledOutput(true); break;
				case '6': printf("VOut OFF\n");dcdcSetEnabledOutput(false); break;
				case '7': printf("INC VOut\n");dcdcIncDecVOutVolatile(true); break;
				case '8': printf("DEC VOut\n");dcdcIncDecVOutVolatile(false); break;
				case '9': printf("Set VOut to 12V\n");dcdcSetVOutVolatile(12.0); break;
				case 'l':
				case 'L': 
					{
						printf("Loading flash values. Wait ...\n");
						dcdcLoadFlashValues();
						int timeout = 0;
						while ((dcdcGetLoadState() < 100) && (timeout < 10))//wait for 10 seconds
						{
							printf("Loading %d%c\n",dcdcGetLoadState(),'%');
							timeout++;
							Sleep(1000);
						}
						printf("Loading final: %d%c\n",dcdcGetLoadState(),'%');
						if (dcdcGetLoadState() == 100)//succesfull
						{
							unsigned int var_max = dcdcGetMaxVariableCnt();
							char name[256];
							char value[256];
							char unit[256];
							char comment[1024];

							for (int i=0;i<var_max;i++)
								if (dcdcGetVariableData(i, name, value, unit, comment))
									printf("[%d] %s=%s %s\n",i,name, value, unit);//, comment);
						}
					}break;
				case 'q':
				case 'Q':
				case 'w':
				case 'W':
					if ((ch == 'q') || (ch == 'Q'))
					{
						dcdcSetVariableData(0, "20.11");//Voltage 0 (VOut at startup)
						dcdcSetVariableData(10, "511");//Ignition debounce
						dcdcSetVariableData(20, "10001101");//config flags
						dcdcSetVariableData(24, "00:11:05");//Off-delay TIME 1
					}
					else
					{
						dcdcSetVariableData(0, "23.00");//Voltage 0 (VOut at startup)
						dcdcSetVariableData(10, "500");//Ignition debounce
						dcdcSetVariableData(20, "00001101");//config flags
						dcdcSetVariableData(24, "00:00:05");//Off-delay TIME 1
					}

					dcdcSaveFlashValues();
					break;
				}
			}
		}
		else
		{
			if (dcdcGetConnected() == false)
			{
				//dcdcCloseDevice();
				printf("No device\n");
			}
			else
			{
				switch (dcdcGetMode())
				{
				case 0: printf("[Dumb] ");break;
				case 1: printf("[Automotive]  ");break;
				case 2: printf("[Script]  ");break;
				case 3: printf("[UPS]  ");break;
				default:printf("[Error]  ");
				}

				printf("State:%02x Vin:%.2f VIgn:%.2f VOut:%.2f SW[Power:%d Output:%d Aux:%d]\n",
					dcdcGetState(), dcdcGetVin(),dcdcGetVIgn(),dcdcGetVOut(),
					dcdcGetEnabledPowerSwitch(), dcdcGetEnabledOutput(),dcdcGetEnabledAuxVOut());
				printf("    CfgT:%02x CfgV:%02x Flags[%02X %02X %02X %02X %02X] Timers[%d %d %d %d %d %d]\n", 
					dcdcGetTimeCfg(),dcdcGetVoltageCfg(),
					dcdcGetFlagsStatus1(),dcdcGetFlagsStatus2(),dcdcGetFlagsVoltage(),dcdcGetFlagsTimer(),dcdcGetFlashPointer(),
					dcdcGetTimerWait(),dcdcGetTimerVout(),dcdcGetTimerVAux(),dcdcGetTimerPwSwitch(),dcdcGetTimerOffDelay(),dcdcGetTimerHardOff());
			}
			Sleep(1000);
		}
	}//while
	dcdcCloseDevice();

	return 0;
}
