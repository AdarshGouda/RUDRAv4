// DcDcUsb.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CDcDcUsbApp:
// See DcDcUsb.cpp for the implementation of this class
//

class CDcDcUsbApp : public CWinApp
{
public:
	CDcDcUsbApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CDcDcUsbApp theApp;