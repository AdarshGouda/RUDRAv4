#include "StdAfx.h"
#include "TiTxtParser.h"

CTiTxtParser::CTiTxtParser(void)
{
}

CTiTxtParser::~CTiTxtParser(void)
{
}
