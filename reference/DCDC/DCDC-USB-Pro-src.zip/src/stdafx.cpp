// stdafx.cpp : source file that includes just the standard includes
// DCDCUSB.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

CString char2bin(unsigned char ch)
{
	CString str;
 
	for (int i=7;i>=0;i--)
		if ((ch>>i)&1)
			str += '1';
		else str += '0';
 
	return str;
}

unsigned char bin2char(CString str, bool* ok)
{
	*ok = false;
	if (str.GetLength() == 0)
		return 0;

	unsigned char value = 0;

	for (int i=0;i<str.GetLength();i++)
	{
		if ((str[i] != '0')&&(str[i] != '1')) return 0;

		if (str[i] == '1')
			value = value | (1 << (str.GetLength()-1-i));
	}

	*ok = true;
	return value;
}

CString float2string(float f)
{
	CString str;
	str.Format("%.2f",f);
	return str;
}

CString bytes2string(unsigned char ch1, unsigned char ch2)
{
	unsigned int i = ch1;
	i = i << 8;
	i = i | ch2;

	CString str;
	str.Format("%d",i);
	return str;
}

