#pragma once


// CSleepDialog dialog

class CSleepDialog : public CDialog
{
	DECLARE_DYNAMIC(CSleepDialog)

public:
	CSleepDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CSleepDialog();

// Dialog Data
	enum { IDD = IDD_DIALOG_SLEEP };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CString m_strSleep;
	afx_msg void OnBnClickedOk();
};
