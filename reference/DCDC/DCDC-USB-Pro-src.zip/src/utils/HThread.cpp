#include "stdafx.h"

#include "HThread.h"
#include <limits.h>

#ifndef _WIN32
#define	INVALID_HANDLE_VALUE	0
#endif

//#define THREAD_DEBUG

const unsigned int HThread::INFINIT_WAIT = UINT_MAX;

HThread::HThread( const char* name )
{
	m_bIsRunning = false;
	m_bExited = true;
	m_thread = INVALID_HANDLE_VALUE;

	strcpy(m_strName, name);
}

HThread::~HThread()
{
	stop();
}

bool HThread::start( void )
{
	if( m_bExited )
	{
#ifdef THREAD_DEBUG
		TRACE("Starting thread %s\n",m_strName);
		printf("Starting thread %s\n",m_strName);
#endif

		m_bIsRunning = true;
		m_bExited = false;

#ifdef _WIN32
		DWORD dw;
		if( (m_thread = CreateThread( NULL, 4096, runStub, this, 0, &dw )) == INVALID_HANDLE_VALUE )
		{
			m_bIsRunning = false;
			m_bExited = true;
			return false;
		}
#else
		pthread_attr_t attr;
		pthread_attr_init( &attr );
		pthread_attr_setdetachstate( &attr, PTHREAD_CREATE_DETACHED );
		pthread_attr_setschedpolicy( &attr, SCHED_OTHER );
		pthread_attr_setscope( &attr, PTHREAD_SCOPE_SYSTEM );
		if( pthread_create( &m_thread, &attr, runStub, this ) != 0 )
		{
			m_thread = INVALID_HANDLE_VALUE;
			m_bIsRunning = false;
			m_bExited = true;
			return false;
		}
#endif

#ifdef THREAD_DEBUG
	TRACE("Started thread %s (%x)\n",m_strName,m_thread);
	printf("Started thread %s (%x)\n",m_strName,m_thread);
#endif
	}
	return true;
}

bool HThread::stop( unsigned int timeout )
{
#ifdef THREAD_DEBUG
	if( !m_bExited )
	{
		TRACE("Stopping thread %s (%x)\n",m_strName,m_thread);
		printf("Stopping thread %s (%x)\n",m_strName,m_thread);
	}
#endif

	m_bIsRunning = false;
	if( !m_bExited )
	{
		for( unsigned int i = 0; (i <= timeout/10) || (timeout == INFINIT_WAIT); i++)
		{
			if( m_bExited )
			{
				break;
			}
			Sleep( 10 );
		}
	}

#ifdef _WIN32
	if( m_thread != INVALID_HANDLE_VALUE )
	{
		if (!m_bExited)
		{
			TRACE("Forcing stop thread %s\n",m_strName);
			printf("Forcing stop thread %s\n",m_strName);

			TerminateThread(m_thread, 10);
		}
		CloseHandle( m_thread );

#ifdef THREAD_DEBUG
		TRACE("Stopped thread %s\n",m_strName);
		printf("Stopped thread %s\n",m_strName);
#endif
		m_thread = INVALID_HANDLE_VALUE;
	}
#else
	m_thread = INVALID_HANDLE_VALUE;
#endif
	return m_bExited;
}

void HThread::run( void )
{
}

#ifdef _WIN32
DWORD WINAPI runStub( LPVOID mthread )
#else
void* runStub( void* mthread)
#endif
{
	HThread* pThread = static_cast<HThread* >(mthread);
	pThread->m_bIsRunning = true;
	pThread->m_bExited = false;
	pThread->run();
	pThread->m_bIsRunning = false;
	pThread->m_bExited = true;
#ifdef _WIN32
	return 0;
#else
	return NULL;
#endif
}
