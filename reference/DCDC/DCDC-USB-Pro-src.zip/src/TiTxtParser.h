#pragma once

class CTiTxtParser
{
public:
	CTiTxtParser(void);
	virtual ~CTiTxtParser(void);
};
