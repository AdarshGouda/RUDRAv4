// PanelStatus.cpp : implementation file
//

#include "stdafx.h"
#include "DcDcUsb.h"
#include "PanelStatus.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CPanelStatus dialog

IMPLEMENT_DYNAMIC(CPanelStatus, CDialog)

CPanelStatus::CPanelStatus(CDcDcUsbDlg* mainDlg, CWnd* pParent /*=NULL*/)
	: CDialog(CPanelStatus::IDD, pParent)
	, m_strState(_T(""))
	, m_strFlagsVoltage(_T(""))
	, m_strFlagsStatus1(_T(""))
	, m_strFlagsStatus2(_T(""))
	, m_strFlagsTimer(_T(""))
	, m_strTimeCfg(_T(""))
	, m_strVoltCfg(_T(""))
	, m_strMode(_T(""))
	, m_strTimerWait(_T(""))
	, m_strTimerVout(_T(""))
	, m_strTimerPwSwitch(_T(""))
	, m_strFlashPointer(_T(""))
	, m_strTimerVAux(_T(""))
	, m_strTimerOffDelay(_T(""))
	, m_strTimerHardOff(_T(""))
{
	m_pMainDlg = mainDlg;
}

CPanelStatus::~CPanelStatus()
{
}

void CPanelStatus::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_STATE, m_strState);
	DDX_Text(pDX, IDC_EDIT_FLAGS_VOLTAGE, m_strFlagsVoltage);
	DDX_Text(pDX, IDC_EDIT_FLAGS_STATUS1, m_strFlagsStatus1);
	DDX_Text(pDX, IDC_EDIT_FLAGS_STATUS2, m_strFlagsStatus2);
	DDX_Text(pDX, IDC_EDIT_FLAGS_TIMER, m_strFlagsTimer);
	DDX_Text(pDX, IDC_EDIT_TIMECFG, m_strTimeCfg);
	DDX_Text(pDX, IDC_EDIT_VOLTCFG, m_strVoltCfg);
	DDX_Text(pDX, IDC_EDIT_MODE, m_strMode);
	DDX_Text(pDX, IDC_EDIT_TIMER_WAIT, m_strTimerWait);
	DDX_Text(pDX, IDC_EDIT_TIMER_VOUT, m_strTimerVout);
	DDX_Text(pDX, IDC_EDIT_TIMER_PWSWITCH, m_strTimerPwSwitch);
	DDX_Text(pDX, IDC_EDIT_FLASH_POINTER, m_strFlashPointer);
	DDX_Text(pDX, IDC_EDIT_TIMER_VAUX, m_strTimerVAux);
	DDX_Text(pDX, IDC_EDIT_TIMER_OFFDELAY, m_strTimerOffDelay);
	DDX_Text(pDX, IDC_EDIT_TIMER_HARDOFF, m_strTimerHardOff);
	DDX_Control(pDX, IDC_EDIT_REGULATOR_STEPS, m_editRegulatorSteps);
}


BEGIN_MESSAGE_MAP(CPanelStatus, CDialog)
END_MESSAGE_MAP()


// CPanelStatus message handlers


