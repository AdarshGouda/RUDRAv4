//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DcDcUsb.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DCDCUSB_DIALOG              102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDB_BITMAP_MINIBOX              130
#define IDD_DIALOG_STATUS               131
#define IDD_DIALOG_SETTINGS             132
#define IDD_DIALOG_SCRIPTS              133
#define IDD_DIALOG_SLEEP                136
#define IDB_BITMAP_DIAGRAM              138
#define IDC_EDIT_TIMECFG                1000
#define IDC_EDIT_VOLTCFG                1001
#define IDC_EDIT_3V                     1002
#define IDC_EDIT_VIN                    1002
#define IDC_EDIT_5V                     1003
#define IDC_EDIT_IGN                    1003
#define IDC_EDIT_12V                    1004
#define IDC_EDIT_VOUT                   1004
#define IDC_EDIT_TEMP                   1005
#define IDC_EDIT_MODE                   1005
#define IDC_EDIT_FLAGS_VOLTAGE          1006
#define IDC_EDIT_FLAGS_STATUS1          1007
#define IDC_EDIT_FLAGS_STATUS2          1008
#define IDC_EDIT_FLAGS_TIMER            1009
#define IDC_EDIT_FLAGS_INPUT            1010
#define IDC_EDIT_VOUTSET                1010
#define IDC_EDIT_FLAGS_OUTPUT           1011
#define IDC_EDIT_STATE                  1012
#define IDC_COMBO_MESSAGE               1013
#define IDC_EDIT_MESSAGE                1014
#define IDC_STATIC_UNIT                 1015
#define IDC_BUTTON_SEND                 1016
#define IDC_STATIC_COMMENT              1017
#define IDC_CHECK_REFRESH               1018
#define IDC_EDIT_STATBUFF               1019
#define IDC_EDIT_STATBUFF2              1020
#define IDC_EDIT_IOBUFF                 1020
#define IDC_CHECK_AUXVIN                1021
#define IDC_EDIT_FLASH_POINTER          1022
#define IDC_CHECK_PANEL_STATUS          1022
#define IDC_EDIT_TIMER_WAIT             1023
#define IDC_CHECK_PANEL_SETTINGS        1023
#define IDC_EDIT_TIMER_VOUT             1024
#define IDC_EDIT_TIMER_PWSWITCH         1025
#define IDC_CHECK_PANEL_MINI            1025
#define IDC_EDIT_TIMER_VAUX             1026
#define IDC_CHECK_PWSW                  1027
#define IDC_EDIT_TIMER_OFFDELAY         1027
#define IDC_CHECK_OUTPUT                1028
#define IDC_EDIT_TIMER_HARDOFF          1028
#define IDC_BUTTON_VOUT_SET             1029
#define IDC_EDIT_REGULATOR_STEPS        1029
#define IDC_BUTTON_VOUT_UP              1030
#define IDC_BUTTON_VOUT_DOWN            1031
#define IDC_BUTTON_LOADDEFVAL           1032
#define IDC_BUTTON_VOUT_SET_SAVE        1032
#define IDC_BUTTON_SCRIPT_START         1033
#define IDC_BUTTON_READSETTINGS         1033
#define IDC_BUTTON_SCRIPT_STOP          1034
#define IDC_BUTTON_WRITESETTINGS        1034
#define IDC_BUTTON_SCRIPT_SEND          1035
#define IDC_CHECK_PANEL_SCRIPTS         1036
#define IDC_BUTTON_SCRIPT_SLEEP         1036
#define IDC_BUTTON_SENDSETTINGS         1039
#define IDC_COMBO_SCRIPTNO              1041
#define IDC_COMBO_VOUT_T1               1042
#define IDC_COMBO_VOUT_T2               1043
#define IDC_EDIT_VOLTAGE                1044
#define IDC_EDIT_VOUT_TIME1             1045
#define IDC_EDIT_VOUT_TIME2             1046
#define IDC_COMBO_VAUX_T1               1047
#define IDC_COMBO_VAUX_T2               1048
#define IDC_EDIT_VAUX_TIME1             1049
#define IDC_EDIT_VAUX_TIME2             1050
#define IDC_COMBO_VPSW_T1               1051
#define IDC_COMBO_VPSW_T2               1052
#define IDC_EDIT_VPSW_TIME1             1053
#define IDC_EDIT_VPSW_TIME2             1054
#define IDC_EDIT_VPSW_TIME3             1055
#define IDC_CHECK_SCRIPT_REPEAT         1056
#define IDC_CHECK_SCRIPT_NEXT           1057
#define IDC_EDIT_SLEEP                  1057
#define IDC_CHECK_SCRIPT_DISABLE        1058
#define IDC_PROGRESS_RW                 1058
#define IDC_STATIC_RW                   1059

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1060
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
