#pragma once
#include "afxwin.h"
class CDcDcUsbDlg;

// CPanelStatus dialog

class CPanelStatus : public CDialog
{
	DECLARE_DYNAMIC(CPanelStatus)

public:
	CPanelStatus(CDcDcUsbDlg* mainDlg, CWnd* pParent = NULL);   // standard constructor
	virtual ~CPanelStatus();

// Dialog Data
	enum { IDD = IDD_DIALOG_STATUS };

protected:
	CDcDcUsbDlg* m_pMainDlg;
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	CString m_strState;
	CString m_strFlagsVoltage;
	CString m_strFlagsStatus1;
	CString m_strFlagsStatus2;
	CString m_strFlagsTimer;
	CString m_strTimeCfg;
	CString m_strVoltCfg;
	CString m_strMode;
	CString m_strTimerWait;
	CString m_strTimerVout;
	CString m_strTimerPwSwitch;
	CString m_strFlashPointer;
	CString m_strTimerVAux;
	CString m_strTimerOffDelay;
	CString m_strTimerHardOff;
	CEdit m_editRegulatorSteps;
};
